package com.jeff.teammate.model;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class Game implements Serializable {
    private int id;

    private String name;

    private byte[] mask;

    //all tags
    private List<Tag> vector;

    //group name to tag list
    private Map<String, List<Tag>> map;

    private static final long serialVersionUID = 0L;

    public String getName() {
        return name;
    }

    public
}
