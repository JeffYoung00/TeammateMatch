package com.jeff.teammate.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface GameMapper {
}
